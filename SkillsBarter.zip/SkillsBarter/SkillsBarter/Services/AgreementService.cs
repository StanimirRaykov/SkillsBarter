using Microsoft.EntityFrameworkCore;
using SkillsBarter.Constants;
using SkillsBarter.Data;
using SkillsBarter.DTOs;
using SkillsBarter.Models;

namespace SkillsBarter.Services;

public class AgreementService : IAgreementService
{
    private readonly ApplicationDbContext _dbContext;
    private readonly INotificationService _notificationService;
    private readonly ILogger<AgreementService> _logger;

    public AgreementService(
        ApplicationDbContext dbContext,
        INotificationService notificationService,
        ILogger<AgreementService> logger)
    {
        _dbContext = dbContext;
        _notificationService = notificationService;
        _logger = logger;
    }

    public async Task<AgreementResponse?> CreateAgreementAsync(
        Guid offerId,
        Guid requesterId,
        Guid providerId,
        string? terms,
        List<CreateMilestoneRequest>? milestones = null
    )
    {
        var existingTransaction = _dbContext.Database.CurrentTransaction;
        var transaction = existingTransaction ?? await _dbContext.Database.BeginTransactionAsync();
        var ownsTransaction = existingTransaction == null;

        try
        {
            if (milestones == null || milestones.Count == 0)
            {
                _logger.LogWarning("Create agreement failed: At least one milestone is required");
                return null;
            }

            var offer = await _dbContext
                .Offers.Include(o => o.User)
                .FirstOrDefaultAsync(o => o.Id == offerId);

            if (offer == null)
            {
                _logger.LogWarning("Create agreement failed: Offer {OfferId} not found", offerId);
                return null;
            }

            if (offer.StatusCode != OfferStatusCode.Active)
            {
                _logger.LogWarning(
                    "Create agreement failed: Offer {OfferId} is not active (Status: {Status})",
                    offerId,
                    offer.StatusCode
                );
                return null;
            }

            var requester = await _dbContext.Users.FindAsync(requesterId);
            if (requester == null)
            {
                _logger.LogWarning(
                    "Create agreement failed: Requester {RequesterId} not found",
                    requesterId
                );
                return null;
            }

            var provider = await _dbContext.Users.FindAsync(providerId);
            if (provider == null)
            {
                _logger.LogWarning(
                    "Create agreement failed: Provider {ProviderId} not found",
                    providerId
                );
                return null;
            }

            if (requesterId == providerId)
            {
                _logger.LogWarning(
                    "Create agreement failed: Requester and provider cannot be the same user"
                );
                return null;
            }

            if (requesterId == offer.UserId)
            {
                _logger.LogWarning(
                    "Create agreement failed: User {UserId} cannot request their own offer {OfferId}",
                    requesterId,
                    offerId
                );
                return null;
            }

            if (offer.UserId != requesterId && offer.UserId != providerId)
            {
                _logger.LogWarning(
                    "Create agreement failed: Neither requester {RequesterId} nor provider {ProviderId} owns offer {OfferId} (Owner: {OwnerId})",
                    requesterId,
                    providerId,
                    offerId,
                    offer.UserId
                );
                return null;
            }

            var existingAgreement = await _dbContext
                .Agreements.Where(a =>
                    a.OfferId == offerId
                    && (
                        a.Status == AgreementStatus.Pending
                        || a.Status == AgreementStatus.InProgress
                    )
                )
                .FirstOrDefaultAsync();

            if (existingAgreement != null)
            {
                _logger.LogWarning(
                    "Create agreement failed: Offer {OfferId} already has an active agreement {AgreementId}",
                    offerId,
                    existingAgreement.Id
                );
                return null;
            }

            var agreement = new Agreement
            {
                Id = Guid.NewGuid(),
                OfferId = offerId,
                RequesterId = requesterId,
                ProviderId = providerId,
                Terms = terms,
                Status = AgreementStatus.InProgress,
                CreatedAt = DateTime.UtcNow,
            };

            _dbContext.Agreements.Add(agreement);

            offer.StatusCode = OfferStatusCode.UnderAgreement;
            if (offer.CreatedAt.Kind == DateTimeKind.Unspecified)
            {
                offer.CreatedAt = DateTime.SpecifyKind(offer.CreatedAt, DateTimeKind.Utc);
            }
            offer.UpdatedAt = DateTime.UtcNow;
            _dbContext.Offers.Update(offer);

            if (milestones != null && milestones.Count > 0)
            {
                foreach (var milestoneRequest in milestones)
                {
                    var responsibleUserId = milestoneRequest.ResponsibleUserId ?? requesterId;

                    var milestone = new Milestone
                    {
                        Id = Guid.NewGuid(),
                        AgreementId = agreement.Id,
                        ResponsibleUserId = responsibleUserId,
                        Title = milestoneRequest.Title?.Trim() ?? string.Empty,
                        DurationInDays = milestoneRequest.DurationInDays,
                        Status = MilestoneStatus.Pending,
                        DueAt = milestoneRequest.DueAt.HasValue
                            ? (milestoneRequest.DueAt.Value.Kind == DateTimeKind.Unspecified
                                ? DateTime.SpecifyKind(milestoneRequest.DueAt.Value, DateTimeKind.Utc)
                                : milestoneRequest.DueAt.Value.ToUniversalTime())
                            : null
                    };
                    _dbContext.Milestones.Add(milestone);
                }
            }

            await _dbContext.SaveChangesAsync();

            if (ownsTransaction)
            {
                await transaction.CommitAsync();
            }

            _logger.LogInformation(
                "Agreement {AgreementId} created for offer {OfferId}. Offer status set to UnderAgreement",
                agreement.Id,
                offerId
            );

            await _notificationService.CreateAsync(
                requesterId,
                NotificationType.AgreementCreated,
                "Agreement Proposal Sent",
                $"You have proposed an agreement to {provider.Name} for '{offer.Title}'",
                agreement.Id
            );
            await _notificationService.CreateAsync(
                providerId,
                NotificationType.AgreementCreated,
                "New Agreement Proposal",
                $"{requester.Name} has proposed an agreement for your offer '{offer.Title}'. Please review and accept/reject.",
                agreement.Id
            );

            return MapToAgreementResponse(agreement);
        }
        catch (Exception ex)
        {
            if (ownsTransaction)
            {
                await transaction.RollbackAsync();
            }
            _logger.LogError(ex, "Error creating agreement for offer {OfferId}", offerId);
            throw;
        }
    }

    public async Task<AgreementResponse?> CompleteAgreementAsync(Guid agreementId, Guid userId)
    {
        try
        {
            var agreement = await _dbContext
                .Agreements.Include(a => a.Offer)
                .FirstOrDefaultAsync(a => a.Id == agreementId);

            if (agreement == null)
            {
                _logger.LogWarning(
                    "Complete agreement failed: Agreement {AgreementId} not found",
                    agreementId
                );
                return null;
            }

            if (agreement.RequesterId != userId && agreement.ProviderId != userId)
            {
                _logger.LogWarning(
                    "Complete agreement failed: User {UserId} is not part of agreement {AgreementId}",
                    userId,
                    agreementId
                );
                return null;
            }

            if (agreement.Status == AgreementStatus.Completed)
            {
                _logger.LogWarning(
                    "Complete agreement failed: Agreement {AgreementId} is already completed",
                    agreementId
                );
                return null;
            }

            agreement.Status = AgreementStatus.Completed;
            agreement.CompletedAt = DateTime.UtcNow;
            _dbContext.Agreements.Update(agreement);

            if (agreement.Offer != null)
            {
                agreement.Offer.StatusCode = OfferStatusCode.Completed;
                agreement.Offer.UpdatedAt = DateTime.UtcNow;
                _dbContext.Offers.Update(agreement.Offer);
            }

            await _dbContext.SaveChangesAsync();

            _logger.LogInformation(
                "Agreement {AgreementId} completed by user {UserId}. Offer {OfferId} status set to Completed",
                agreementId,
                userId,
                agreement.OfferId
            );

            await _notificationService.CreateAsync(
                agreement.RequesterId,
                NotificationType.AgreementCompleted,
                "Agreement Completed",
                $"Agreement #{agreementId.ToString()[..8]} is marked complete. Please leave a review.",
                agreementId
            );
            await _notificationService.CreateAsync(
                agreement.ProviderId,
                NotificationType.AgreementCompleted,
                "Agreement Completed",
                $"Agreement #{agreementId.ToString()[..8]} is marked complete. Please leave a review.",
                agreementId
            );

            return MapToAgreementResponse(agreement);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error completing agreement {AgreementId}", agreementId);
            throw;
        }
    }

    public async Task<AgreementResponse?> GetAgreementByIdAsync(Guid agreementId)
    {
        try
        {
            var agreement = await _dbContext.Agreements.FirstOrDefaultAsync(a =>
                a.Id == agreementId
            );

            if (agreement == null)
            {
                _logger.LogWarning("Agreement {AgreementId} not found", agreementId);
                return null;
            }

            return MapToAgreementResponse(agreement);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving agreement {AgreementId}", agreementId);
            throw;
        }
    }

    public async Task<AgreementDetailResponse?> GetAgreementDetailByIdAsync(Guid agreementId)
    {
        try
        {
            var agreement = await _dbContext
                .Agreements.Include(a => a.Requester)
                .Include(a => a.Provider)
                .Include(a => a.Offer)
                    .ThenInclude(o => o.Skill)
                .Include(a => a.Milestones)
                    .ThenInclude(m => m.ResponsibleUser)
                .Include(a => a.Payments)
                .Include(a => a.Reviews)
                    .ThenInclude(r => r.Reviewer)
                .Include(a => a.Reviews)
                    .ThenInclude(r => r.Recipient)
                .FirstOrDefaultAsync(a => a.Id == agreementId);

            if (agreement == null)
            {
                _logger.LogWarning("Agreement {AgreementId} not found", agreementId);
                return null;
            }

            return MapToAgreementDetailResponse(agreement);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving agreement details {AgreementId}", agreementId);
            throw;
        }
    }

    public async Task<AgreementListResponse> GetUserAgreementsAsync(Guid userId, AgreementStatus? status = null, int page = 1, int pageSize = 10)
    {
        try
        {
            var query = _dbContext.Agreements
                .Include(a => a.Requester)
                .Include(a => a.Provider)
                .Include(a => a.Offer)
                    .ThenInclude(o => o.Skill)
                .Include(a => a.Milestones)
                .Include(a => a.Reviews)
                .Where(a => a.RequesterId == userId || a.ProviderId == userId);

            if (status.HasValue)
            {
                query = query.Where(a => a.Status == status.Value);
            }

            var totalCount = await query.CountAsync();

            var agreements = await query
                .OrderByDescending(a => a.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var summaries = agreements.Select(a => new AgreementSummaryResponse
            {
                Id = a.Id,
                OfferId = a.OfferId,
                OfferTitle = a.Offer.Title,
                SkillName = a.Offer.Skill?.Name ?? "Unknown",
                RequesterId = a.RequesterId,
                RequesterName = a.Requester.Name,
                ProviderId = a.ProviderId,
                ProviderName = a.Provider.Name,
                Status = a.Status,
                CreatedAt = a.CreatedAt,
                CompletedAt = a.CompletedAt,
                TotalMilestones = a.Milestones.Count,
                CompletedMilestones = a.Milestones.Count(m => m.Status == MilestoneStatus.Completed),
                Role = a.RequesterId == userId ? "Requester" : "Provider",
                HasReviewFromMe = a.Reviews.Any(r => r.ReviewerId == userId)
            }).ToList();

            return new AgreementListResponse
            {
                Agreements = summaries,
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving agreements for user {UserId}", userId);
            throw;
        }
    }

    private AgreementResponse MapToAgreementResponse(Agreement agreement)
    {
        return new AgreementResponse
        {
            Id = agreement.Id,
            OfferId = agreement.OfferId,
            RequesterId = agreement.RequesterId,
            ProviderId = agreement.ProviderId,
            Terms = agreement.Terms,
            Status = agreement.Status,
            CreatedAt = agreement.CreatedAt,
            AcceptedAt = agreement.AcceptedAt,
            CompletedAt = agreement.CompletedAt,
        };
    }

    private AgreementDetailResponse MapToAgreementDetailResponse(Agreement agreement)
    {
        return new AgreementDetailResponse
        {
            Id = agreement.Id,
            OfferId = agreement.OfferId,
            RequesterId = agreement.RequesterId,
            ProviderId = agreement.ProviderId,
            Terms = agreement.Terms,
            Status = agreement.Status,
            CreatedAt = agreement.CreatedAt,
            AcceptedAt = agreement.AcceptedAt,
            CompletedAt = agreement.CompletedAt,
            Requester = new AgreementUserInfo
            {
                Id = agreement.Requester.Id,
                Name = agreement.Requester.Name,
                Email = agreement.Requester.Email ?? string.Empty,
                VerificationLevel = agreement.Requester.VerificationLevel,
                ReputationScore = agreement.Requester.ReputationScore,
            },
            Provider = new AgreementUserInfo
            {
                Id = agreement.Provider.Id,
                Name = agreement.Provider.Name,
                Email = agreement.Provider.Email ?? string.Empty,
                VerificationLevel = agreement.Provider.VerificationLevel,
                ReputationScore = agreement.Provider.ReputationScore,
            },
            Offer = new AgreementOfferInfo
            {
                Id = agreement.Offer.Id,
                Title = agreement.Offer.Title,
                Description = agreement.Offer.Description,
                SkillName = agreement.Offer.Skill.Name,
                StatusCode = agreement.Offer.StatusCode.ToString(),
            },
            Milestones = agreement
                .Milestones.Select(m => new MilestoneInfo
                {
                    Id = m.Id,
                    ResponsibleUserId = m.ResponsibleUserId,
                    ResponsibleUserName = m.ResponsibleUser?.Name ?? string.Empty,
                    Title = m.Title,
                    DurationInDays = m.DurationInDays,
                    Status = m.Status,
                    DueAt = m.DueAt,
                })
                .ToList(),
            Payments = agreement
                .Payments.Select(p => new PaymentInfo
                {
                    Id = p.Id,
                    MilestoneId = p.MilestoneId,
                    TipFromUserId = p.TipFromUserId,
                    TipToUserId = p.TipToUserId,
                    Amount = p.Amount,
                    Currency = p.Currency,
                    PaymentType = p.PaymentType,
                    Status = p.Status,
                    CreatedAt = p.CreatedAt,
                })
                .ToList(),
            Reviews = agreement
                .Reviews.Select(r => new ReviewInfo
                {
                    Id = r.Id,
                    ReviewerId = r.ReviewerId,
                    ReviewerName = r.Reviewer.Name,
                    RecipientId = r.RecipientId,
                    RecipientName = r.Recipient.Name,
                    Rating = r.Rating,
                    Body = r.Body,
                    CreatedAt = r.CreatedAt,
                })
                .ToList(),
        };
    }

    public async Task<AdminAgreementListResponse> GetAllAgreementsAsync(AgreementStatus? status = null, int page = 1, int pageSize = 20)
    {
        try
        {
            var query = _dbContext.Agreements
                .Include(a => a.Requester)
                .Include(a => a.Provider)
                .Include(a => a.Offer)
                    .ThenInclude(o => o.Skill)
                .Include(a => a.Milestones)
                .Include(a => a.Deliverables)
                .Include(a => a.Disputes)
                .AsQueryable();

            if (status.HasValue)
            {
                query = query.Where(a => a.Status == status.Value);
            }

            var totalCount = await query.CountAsync();

            var agreements = await query
                .OrderByDescending(a => a.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var summaries = agreements.Select(a => new AdminAgreementSummaryResponse
            {
                Id = a.Id,
                OfferId = a.OfferId,
                OfferTitle = a.Offer.Title,
                SkillName = a.Offer.Skill?.Name ?? "Unknown",
                RequesterId = a.RequesterId,
                RequesterName = a.Requester.Name,
                RequesterEmail = a.Requester.Email ?? string.Empty,
                ProviderId = a.ProviderId,
                ProviderName = a.Provider.Name,
                ProviderEmail = a.Provider.Email ?? string.Empty,
                Status = a.Status,
                CreatedAt = a.CreatedAt,
                AcceptedAt = a.AcceptedAt,
                CompletedAt = a.CompletedAt,
                TotalMilestones = a.Milestones.Count,
                CompletedMilestones = a.Milestones.Count(m => m.Status == MilestoneStatus.Completed),
                TotalDeliverables = a.Deliverables.Count,
                ApprovedDeliverables = a.Deliverables.Count(d => d.Status == DeliverableStatus.Approved),
                HasDispute = a.Disputes.Any(d => d.Status == DisputeStatus.Open || d.Status == DisputeStatus.UnderReview)
            }).ToList();

            return new AdminAgreementListResponse
            {
                Agreements = summaries,
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all agreements for admin");
            throw;
        }
    }

    public async Task ProcessAbandonedAgreementsAsync()
    {
        var abandonmentThreshold = DateTime.UtcNow.AddDays(-PenaltyConstants.AbandonmentDays);

        var abandonedAgreements = await _dbContext
            .Agreements.Include(a => a.Deliverables)
            .Where(a =>
                a.Status == AgreementStatus.InProgress
                && a.CreatedAt < abandonmentThreshold
                && !a.Deliverables.Any()
            )
            .ToListAsync();

        foreach (var agreement in abandonedAgreements)
        {
            CreatePenaltiesForAbandonedAgreement(agreement);
            agreement.Status = AgreementStatus.Cancelled;

            _logger.LogInformation(
                "Agreement {AgreementId} marked as abandoned. Penalties created for both parties.",
                agreement.Id
            );

            await _notificationService.CreateAsync(
                agreement.RequesterId,
                NotificationType.AgreementCancelled,
                "Agreement Cancelled",
                $"Agreement #{agreement.Id.ToString()[..8]} has been cancelled due to inactivity",
                agreement.Id
            );
            await _notificationService.CreateAsync(
                agreement.ProviderId,
                NotificationType.AgreementCancelled,
                "Agreement Cancelled",
                $"Agreement #{agreement.Id.ToString()[..8]} has been cancelled due to inactivity",
                agreement.Id
            );
        }

        if (abandonedAgreements.Count > 0)
            await _dbContext.SaveChangesAsync();
    }

    private void CreatePenaltiesForAbandonedAgreement(Agreement agreement)
    {
        var penalties = new[]
        {
            CreatePenalty(agreement.RequesterId, agreement.Id),
            CreatePenalty(agreement.ProviderId, agreement.Id),
        };

        _dbContext.Penalties.AddRange(penalties);
    }

    private static Penalty CreatePenalty(Guid userId, Guid agreementId) =>
        new()
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            AgreementId = agreementId,
            Amount = PenaltyConstants.FullPenaltyAmount,
            Currency = PenaltyConstants.DefaultCurrency,
            Reason = PenaltyReason.AgreementAbandoned,
            Status = PenaltyStatus.Charged,
            CreatedAt = DateTime.UtcNow,
            ChargedAt = DateTime.UtcNow,
        };
}
